"""
Tests parse_listings_from_text() against a real page captured from
hddbroker.com (scraper/fixtures/catid1_page1.md), so the parsing logic is
proven against genuine site content even though this sandbox can't make
live HTTP requests to verify the fetching half of the scraper.

The fixture was saved as extracted markdown. To approximate what
BeautifulSoup's soup.get_text(separator="\\n") would hand back from the
real HTML on a live run, we strip the markdown-only artifacts (heading
hashes, [text](url) link syntax, leading bullet markers) before parsing.
Run with: python3 test_parser.py
"""

import re
from pathlib import Path

from scrape_hddbroker import parse_listings_from_text


def normalize_markdown_fixture(md_text: str) -> str:
    # NOTE: same-line whitespace only ([ \t], not \s) -- \s also matches
    # newlines, which was greedily eating multiple bullet lines into one.
    text = re.sub(r"^[ \t]*#{1,6}[ \t]*", "", md_text, flags=re.MULTILINE)
    text = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"^[ \t]*[-*][ \t]*", "", text, flags=re.MULTILINE)
    return text


def run():
    fixture_path = Path(__file__).parent / "fixtures" / "catid1_page1.md"
    raw = fixture_path.read_text()
    text = normalize_markdown_fixture(raw)

    listings = parse_listings_from_text(text, "HDD Drills")

    expected = [
        dict(ref_id="40688", year=2012, manufacturer="Ditch Witch", hours=3670,
             price_usd=120000, status="New"),
        dict(ref_id="40677", year=2021, manufacturer="Vermeer", hours=None,
             price_usd=None, status="New"),
        dict(ref_id="40676", year=2021, manufacturer="Ditch Witch", hours=1022,
             price_usd=None, status="New"),
        dict(ref_id="40670", year=2024, manufacturer="Vermeer", hours=2331,
             price_usd=120000, status="New"),
        dict(ref_id="40669", year=2025, manufacturer="Vermeer", hours=2208,
             price_usd=207000, status="New"),
        dict(ref_id="40668", year=2014, manufacturer="Vermeer", hours=4763,
             price_usd=59900, status="New"),
        dict(ref_id="40311", year=2014, manufacturer="Ditch Witch", hours=3344,
             price_usd=180000, status="Price Reduced"),
        dict(ref_id="38138", year=2018, manufacturer="Vermeer", hours=3943,
             price_usd=53500, status="Updated"),
    ]

    assert len(listings) == len(expected), (
        f"expected {len(expected)} listings, parsed {len(listings)}"
    )

    failures = []
    for got, want in zip(listings, expected):
        for key, want_val in want.items():
            got_val = getattr(got, key)
            if got_val != want_val:
                failures.append(
                    f"ref {want['ref_id']}: {key} = {got_val!r}, expected {want_val!r}"
                )

    # spot-check a couple of fields the table above doesn't cover
    d = {l.ref_id: l for l in listings}
    if d["40138" if False else "38138"].price_display != "$53,500 USD o.b.o.":
        failures.append(f"38138 price_display = {d['38138'].price_display!r}")
    if d["40668"].model != "D20x22 Series II":
        failures.append(f"40668 model = {d['40668'].model!r}")

    if failures:
        print(f"FAILED: {len(failures)} mismatch(es)")
        for f in failures:
            print(" -", f)
        raise SystemExit(1)

    print(f"PASSED: all {len(listings)} listings parsed correctly from real fixture data.")
    for l in listings:
        print(f"  [{l.status or '-':13s}] {l.title:38s} {l.hours or 0:>6} hrs  "
              f"{l.price_display:>18s}  ({l.manufacturer})")


if __name__ == "__main__":
    run()
