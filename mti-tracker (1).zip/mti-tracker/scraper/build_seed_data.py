"""
One-off script (not part of the daily scrape) that builds the initial
data/latest.json seed from real HDDBroker listings gathered while
researching this project on 2026-08-18, so the dashboard has real
current-market data to show before the first scheduled scrape runs.

Reuses parse_listings_from_text() -- the same tested parser the live
scraper uses -- so the seed data matches the real schema exactly.
"""

import json
import sys
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from scrape_hddbroker import parse_listings_from_text  # noqa: E402

# (status_or_None, title_line, description_line, category) for each
# real listing observed. Status is a standalone line inserted right
# before the title, exactly like the live page renders it.
RAW = [
    ("New", "2023 Ditch Witch AT32 All Terrain Ref #40601",
     "Comes with (1) Tall Basket with (40) AT Drill Rods! 4,792 hours.", "HDD Drills"),
    ("New", "2021 Universal UNI 25 Ref #40594",
     "Comes with 500 feet of Drill Pipe! 905 hours.", "HDD Drills"),
    ("New", "2017 Vermeer D24x40 S3 Ref #40602",
     "Comes with Drill, Mud Mixing System, Truck, and Trailer! 4,314 hours.", "HDD Drills"),
    (None, "2026 Ditch Witch JT21 Ref #40243",
     "60 Hours! Pipe, Tooling, Mixer and Trailer! Under Warranty, Field-Ready, "
     "Complete Drill Package! 60 hours.", "HDD Drills"),
    (None, "2018 Universal UNI 45x65 Ref #40239",
     "Machine Only! 5,354 hours.", "HDD Drills"),
    (None, "2020 Vermeer D23x30DR S3 Ref #38989",
     "(29) Pieces of Rock Drill Pipe are included! 2,509 hours.", "HDD Drills"),
    ("New", "2024 Barbco Tribor36 Ref #40687",
     "Complete Auger Boring, Guided Boring, Directional Drilling Machine Package! "
     "278 hours.", "Auger Boring / Tunnelling"),
    ("New", "2016 McLaughlin VX30-1200 Ref #40686",
     "Vacuum Trailer! 3,277 hours.", "Vacuum Systems"),
    ("New", "2024 Ditch Witch JT10 Ref #40675",
     "Deutz 49 HP Engine! FMC Pump! 1,362 hours.", "HDD Drills"),
    ("New", "2018 Ditch Witch JT30 Ref #40667",
     "Comes with Directional Drill, Equipment Trailer and a Flat Bed Truck!", "HDD Drills"),
    ("New", "2015 Ditch Witch JT30 All Terrain Ref #40663",
     "Enclosed Cab Drill Rig comes with 750 feet of All Terrain Pipe in (1) Tall "
     "and (2) Short Boxes! 2,200 hours.", "HDD Drills"),
    ("New", "2012 Ditch Witch JT3020 Mach 1 Ref #40660",
     "500 Feet of Drill Pipe is included! 1,528 hours.", "HDD Drills"),
    ("New", "2021 Vermeer D23x30 S3 Ref #40658",
     "Recent Service! 2,500 hours.", "HDD Drills"),
    ("New", "2026 Vermeer D24G4 Ref #40657",
     "109 Hours Only! 109 hours.", "HDD Drills"),
    ("New", "2020 Ditch Witch JT24 Ref #40655",
     "Comes with (40) Drill Pipe! 1,029 hours.", "HDD Drills"),
    ("New", "2020 Vermeer D20x22 S3 Ref #40651",
     "(40) Drill Rods are included! Deutz 74 HP! FMC Pump! Rubber Tracks! 1,979 hours.",
     "HDD Drills"),
    ("New", "2014 Ditch Witch JT20 Ref #40649",
     "Comes with Equipment Trailer, Locating Equipment and Drill Pipe! 3,120 hours.",
     "HDD Drills"),
    ("New", "2016 Vermeer D20x22 S3 Ref #40635",
     "Comes with a Full Rack of Drill Pipe! 3,339 hours.", "HDD Drills"),
    ("New", "2015 Ditch Witch JT20 Ref #40634",
     "Includes a Full Rack of Pipe! 5,246 hours.", "HDD Drills"),
    ("New", "2018 Ditch Witch JT30 Ref #40633",
     "Enclosed Cab Drill Rig comes with Drill Pipe!", "HDD Drills"),
    ("New", "2019 Vermeer D23x30 S3 Ref #40631",
     "Comes with (40) used 2.375 inch Firestick Drill Rods! 3,114 hours.", "HDD Drills"),
    ("New", "2014 Vermeer D24x40 Series II Ref #40630",
     "(50) Joints (500 feet) of Drill Pipe is included! 4,050 hours.", "HDD Drills"),
]

# Prices, keyed by ref id (kept separate above since some are "Call for
# pricing" or have "o.b.o." suffixes).
PRICES = {
    "40601": "$235,000 USD", "40594": "$114,000 USD", "40602": "$404,000 USD o.b.o.",
    "40243": "$305,000 USD", "40239": "$16,500 USD", "38989": "$199,000 USD",
    "40687": "$796,000 USD", "40686": "$67,000 USD", "40675": "Call for pricing",
    "40667": "$201,000 USD", "40663": "$212,000 USD", "40660": "$179,000 USD",
    "40658": "$185,000 USD", "40657": "$293,000 USD", "40655": "$189,000 USD",
    "40651": "$162,000 USD", "40649": "$114,000 USD", "40635": "$84,900 USD",
    "40634": "$58,900 USD", "40633": "$129,000 USD", "40631": "$125,000 USD",
    "40630": "$98,000 USD",
}


def build_block(status, title_line, desc_line, price_line):
    parts = []
    if status:
        parts.append(status)
    parts.append(title_line)
    parts.append(desc_line)
    parts.append("Info Check")
    parts.append(price_line)
    return "\n".join(parts)


def main():
    all_listings = []
    by_category = {}
    for status, title_line, desc_line, category in RAW:
        ref = title_line.split("Ref #")[1].strip()
        price_line = PRICES[ref]
        block = build_block(status, title_line, desc_line, price_line)
        by_category.setdefault(category, []).append(block)

    for category, blocks in by_category.items():
        text = "\n".join(blocks)
        all_listings.extend(parse_listings_from_text(text, category))

    # also fold in the 8 listings from the tested fixture (catid1_page1.md)
    # so the seed set matches everything gathered, deduped by ref_id
    from test_parser import normalize_markdown_fixture
    fixture_path = Path(__file__).parent / "fixtures" / "catid1_page1.md"
    fixture_text = normalize_markdown_fixture(fixture_path.read_text())
    all_listings.extend(parse_listings_from_text(fixture_text, "HDD Drills"))

    seen = set()
    deduped = []
    for l in all_listings:
        if l.ref_id in seen:
            continue
        seen.add(l.ref_id)
        deduped.append(l)

    deduped.sort(key=lambda l: int(l.ref_id), reverse=True)

    snapshot = {
        "last_updated": "2026-08-18T00:00:00+00:00",
        "source": "hddbroker.com",
        "note": (
            "Seed data gathered manually while setting this tracker up on "
            "2026-08-18, covering the HDD Drills, Auger Boring / Tunnelling, "
            "and Vacuum Systems categories. The scheduled scraper replaces "
            "this with a full sweep of all tracked categories on its first run."
        ),
        "categories_tracked": [
            "HDD Drills", "Trenchers", "Plows", "Electronics / Locators",
            "Auger Boring / Tunnelling", "Vacuum Systems",
            "Mud Mixing Systems / Tanks", "Mud Recycling Systems",
        ],
        "total_listings": len(deduped),
        "changes_since_last_run": {
            "new_ids": [], "removed_ids": [], "price_drop_ids": [], "price_increase_ids": [],
        },
        "listings": [asdict(l) for l in deduped],
    }

    out_path = Path(__file__).parent.parent / "data" / "latest.json"
    out_path.write_text(json.dumps(snapshot, indent=2))
    print(f"Wrote {len(deduped)} listings to {out_path}")


if __name__ == "__main__":
    main()
