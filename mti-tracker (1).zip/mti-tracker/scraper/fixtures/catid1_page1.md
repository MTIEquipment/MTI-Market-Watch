- [Found 342 listings](#listing-results)

- New

  
      [](https://www.hddbroker.com/en/listings/viewlisting.php?id=40688)  
        ### [2012 Ditch Witch JT4020 Mach 1 Ref #40688](https://www.hddbroker.com/en/listings/viewlisting.php?id=40688)
  
  Overseas Enclosed Cab Drill Rig comes with a Full Rack of Drill Pipe! 3,670 hours.
  
  Info Check

  *
  *
  *
  *
  *
  *
  *
  *
  $120,000 USD

- New

  
      [](https://www.hddbroker.com/en/listings/viewlisting.php?id=40677)  
        ### [2021 Vermeer D40x55 S3 Ref #40677](https://www.hddbroker.com/en/listings/viewlisting.php?id=40677)
  
  15 Foot Rack Machine! John Deere 140HP! Aplex Pump!
  
  Info Check

  *
  *
  *
  *
  *
  *
  *
  *
  Call for pricing

- New

  
      [](https://www.hddbroker.com/en/listings/viewlisting.php?id=40676)  
        ### [2021 Ditch Witch JT28 Ref #40676](https://www.hddbroker.com/en/listings/viewlisting.php?id=40676)
  
  Rubber Tracks! FMC Pump! 130 HP Cummins Diesel Engine! 1,022 hours.
  
  Info Check

  *
  *
  *
  *
  *
  *
  *
  *
  Call for pricing

- New

  
      [](https://www.hddbroker.com/en/listings/viewlisting.php?id=40670)  
        ### [2024 Vermeer D10x15 S3 Ref #40670](https://www.hddbroker.com/en/listings/viewlisting.php?id=40670)
  
  Comes with (50) pieces of Drill Pipe! 2,331 hours.
  
  Info Check

  *
  *
  *
  *
  *
  *
  *
  *
  $120,000 USD

- New

  
      [](https://www.hddbroker.com/en/listings/viewlisting.php?id=40669)  
        ### [2025 Vermeer D20x22 S3 Ref #40669](https://www.hddbroker.com/en/listings/viewlisting.php?id=40669)
  
  Comes with (40) Drill Pipe! Package items Available! 2,208 hours.
  
  Info Check

  *
  *
  *
  *
  *
  *
  *
  *
  $207,000 USD

- New

  
      [](https://www.hddbroker.com/en/listings/viewlisting.php?id=40668)  
        ### [2014 Vermeer D20x22 Series II Ref #40668](https://www.hddbroker.com/en/listings/viewlisting.php?id=40668)
  
  This machine comes with Drill Pipe! 4,763 hours.
  
  Info Check

  *
  *
  *
  *
  *
  *
  *
  *
  $59,900 USD

- Price Reduced

  
      [](https://www.hddbroker.com/en/listings/viewlisting.php?id=40311)  
        ### [2014 Ditch Witch JT60 Ref #40311](https://www.hddbroker.com/en/listings/viewlisting.php?id=40311)
  
  Enclosed Cab Drill Rig includes Drill Pipe! 3,344 hours.
  
  Info Check

  *
  *
  *
  *
  *
  *
  *
  *
  $180,000 USD

- Updated

  
      [](https://www.hddbroker.com/en/listings/viewlisting.php?id=38138)  
        ### [2018 Vermeer D8x12 Ref #38138](https://www.hddbroker.com/en/listings/viewlisting.php?id=38138)
  
  Comes with Drill Pipe, Mud Mixing System and Equipment Trailer! 3,943 hours.
  
  Info Check

  *
  *
  *
  *
  *
  *
  *
  *
  $53,500 USD o.b.o.
